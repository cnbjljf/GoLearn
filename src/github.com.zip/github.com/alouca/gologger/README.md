gologger
========

A simple CLI/File logger for Go